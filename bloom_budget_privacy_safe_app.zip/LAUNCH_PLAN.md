# Bloom Budget — launch and monetization plan

## What works now
Responsive phone/computer web app, JMD calculations, household/Child 1/Child 2/personal/daily spending, editable rows, paid/unpaid colour coding, automatic money-left figures, multiple months, browser-local persistence, JSON backup and restore. Hosted HTTPS deployment can make it installable as a web app in supported browsers.

## Important limits
The app is a local-device prototype. It does not have accounts, cloud sync, customer payments, an admin dashboard, password reset, or subscription enforcement. Do not market it as a secure multiuser financial service yet. It does not link to bank accounts. Export backups regularly.

## Business model proposal (test, not guaranteed revenue)
- Free: one monthly budget, manual entries, basic paid/unpaid tracking.
- Premium: J$500/month or J$5,000/year as an initial pricing experiment; add multiple family profiles, cloud sync, recurring reminders, reports, and budget templates.
- 100 paying subscribers at J$500/month = J$50,000 gross monthly, before fees, taxes, refunds, hosting, support and marketing.

## Path to launch
1. Test with 5–10 adults and fix usability issues; check math with paid/unpaid, budget/actual, negative balances.
2. Choose a public brand/domain and verify name availability and trademarks.
3. Build secure authentication and hosted per-user database with access controls, encryption in transit, backup/recovery, privacy policy and data deletion/export.
4. Choose a payment provider that actually supports Jamaican merchants, JMD or your chosen settlement currency, and subscriptions. Confirm current eligibility and fees directly with the provider. Use hosted checkout and verified webhooks, not payment card fields in this prototype.
5. Add server-side subscription checks, terms, support contact, analytics with consent, and a clear free tier.
6. Host on HTTPS, test installation on Android/iPhone/desktop and launch a limited beta before a public release.
7. If publishing in mobile app stores, check current store billing and review requirements for digital subscriptions.
