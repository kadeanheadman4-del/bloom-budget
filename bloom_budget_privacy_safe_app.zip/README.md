# Bloom Budget — privacy-safe test app

Open `index.html` on your computer to try the app. For phone access, upload these files to an HTTPS static hosting service.

The public template uses **Child 1** and **Child 2**, not private names. It automatically migrates older browser records and imported backups to these generic category names.

This is a test prototype. Data is stored in each browser, not synced across devices. Use Export backup regularly. No subscription billing, customer accounts, or cloud storage are connected.

For monetization, see `LAUNCH_PLAN.md`.
